class Product{
    constructor(id=0, name='', desc='', price=0.0, url=''){
        this.id = id;
        this.name = name;
        this.desc = desc;
        this.price = price;
        this.url = url;
        this.isMarked = false;
    }
    toggle(){
        this.isMarked = !this.isMarked;
    }
    
}
export default Product;
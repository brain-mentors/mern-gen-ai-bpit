const API_KEY = 'AQ.Ab8RN6JuNJOuvAUnhOuV-0N5K_6iJailtobeeLmT4SdeHJiBpw';
const POST_URL = 'https://generativelanguage.googleapis.com/v1beta/interactions';

const doServerCall = ()=>{
    fetch(POST_URL);
}
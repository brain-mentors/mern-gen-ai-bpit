function initCount(){
    let count = 0;
    const plus = ()=>{
        count++;
        return count;
    }
    return plus;
}
export default initCount;

  // Import the functions you need from the SDKs you need
  import { initializeApp } from "https://www.gstatic.com/firebasejs/12.16.0/firebase-app.js";
  import { getAnalytics } from "https://www.gstatic.com/firebasejs/12.16.0/firebase-analytics.js";
  import { getFirestore } from "https://www.gstatic.com/firebasejs/12.16.0/firebase-firestore.js";
  // TODO: Add SDKs for Firebase products that you want to use
  // https://firebase.google.com/docs/web/setup#available-libraries

  // Your web app's Firebase configuration
  // For Firebase JS SDK v7.20.0 and later, measurementId is optional
  const firebaseConfig = {
    apiKey: "AIzaSyDH0Cq6FWbtzNP8lbRx1fVZ5dL_AMRqzDQ",
    authDomain: "productcrudapp-a2612.firebaseapp.com",
    projectId: "productcrudapp-a2612",
    storageBucket: "productcrudapp-a2612.firebasestorage.app",
    messagingSenderId: "879477869728",
    appId: "1:879477869728:web:ac99984c43a1ef39b4cdc5",
    measurementId: "G-LS00K9HBC7"
  };

  // Initialize Firebase
  const app = initializeApp(firebaseConfig);
  const analytics = getAnalytics(app);
  export const db = getFirestore(app);

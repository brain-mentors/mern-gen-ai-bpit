import Product from "../models/product-model.js";
import { db } from "../utils/firebase-config.js";
 import { collection, doc, setDoc, getDocs } from "https://www.gstatic.com/firebasejs/12.16.0/firebase-firestore.js"; 

// Service contains Product Operations
 export const productOperations = {
    products:[],
    getProductSize(){
        return this.products.length;
    },
    getAllProducts(){
        return this.products;
    },
    save(){
        this.products.forEach(async (product)=>{
           // Add a new document with a generated id
        const productObject = doc(collection(db, "products"));
        const simpleObject = {}; // Object Literal
        for(let key in product){
            simpleObject[key] = product[key];
        }
        const r = await setDoc(productObject, simpleObject);
        console.log('R is ', r);
            
        })
        
    },
    async load(){
        const querySnapshot = await getDocs(collection(db, "products"));
        querySnapshot.forEach(p=>{
            console.log(p.data());
        })
    },
    mark(id){
        const productObject = this.products.find(product=>product.id == id);
        if(productObject){
            productObject.toggle();
        }
        console.log('Products ', this.products);
    },
    markCount(){
        return this.products.filter(product=>product.isMarked).length;
    },
    unMarkCount(){
        return this.getProductSize() - this.markCount();
    },
    // add:function(product){

    // }
    add(product){
       // this.products
        console.log(" I am in Service ", product);
        const productObject = new Product();
        for(let key in product){
            productObject[key] = product[key];
        }
        this.products.push(productObject);
        console.log('Product Array ', this.products);
        return productObject;
    },
    remove(){
        this.products = this.products.filter(product=>!product.isMarked)
    },
    search(){

    },
    update(){

    },
    sort(){

    }
}
//export default productOperations;
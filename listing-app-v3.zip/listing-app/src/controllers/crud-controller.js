//alert("I am in Controller");
import {productOperations} from '../services/product-service.js';
import initCount from '../utils/auto-gen.js';
window.addEventListener('DOMContentLoaded', init);
let plus ;
function init(){
    plus = initCount();
    printId();
    document.querySelector('#name').focus();
    showCount();
    bindEvents();
}
function showCount(){
    document.querySelector('#total').innerText = productOperations.getProductSize();
    document.querySelector('#mark-total').innerText = productOperations.markCount();
    document.querySelector('#unmark-total').innerText = productOperations.unMarkCount();
    
}
const printId = ()=>
    document.querySelector('#id').innerText = plus();


function bindEvents(){
    
document.querySelector("#add").addEventListener("click", add);

}
function readFields(){
    const product = {}; // Object Literal
    const fields =['id', 'name', 'desc', 'price', 'url'];
    for(let field of fields){
        if(field ==='id'){ // for label
             product[field] = document.querySelector(`#${field}`).innerText;
             continue; // skip the current iteration
        }
        product[field] = document.querySelector(`#${field}`).value;
    }
    
    return product;
    // const id = document.querySelector('#id').value;
    // product.id = id;
    // const name = document.querySelector('#name').value;
    // product.name = name;
}
function add(){
    console.log(" Add Call");
   // read fields from view (UI)
   const product = readFields();
   const productObject = productOperations.add(product);
   print(productObject);
   clearFields();
   printId();
   showCount();
   //console.log(product);
}

function clearFields(){
    const fields =['id', 'name', 'desc', 'price', 'url'];
    for(let field of fields){
        if(field ==='id'){ // for label
              document.querySelector(`#${field}`).innerText = '';
             continue; // skip the current iteration
        }
         document.querySelector(`#${field}`).value = '';
    }
    document.querySelector('#name').focus();
}

function print(product){
    const tbody = document.querySelector('#products');
    const tr = tbody.insertRow();
    for(let key in product){
        const value = product[key];
        const td = tr.insertCell();
        td.innerText = value;
    }
    const td = tr.insertCell();
    td.appendChild(createIcon(product.id));
    td.appendChild(createIcon(product.id, 'fa-pen-to-square'))
}

function createIcon(productId, className ='fa-trash'){
    // <i class="fa-solid fa-trash"></i>
    const icon = document.createElement('i'); //<i></i>
    icon.setAttribute('product-id', productId);
    icon.className =`fa-solid ${className} hand`;
    return icon;
}

function toggleMark(id){

}

function edit(id){

}
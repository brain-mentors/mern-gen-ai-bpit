import Title from "../components/Title";
import Text from "../components/Text";
import { Button } from "../components/Button";
import { useState } from "react";
const VotingApp = () => {
  const [count, setCount] = useState(0);
  const compute = (operation) => {
    if (operation === "+") {
      setCount(count + 1);
    } else {
      setCount(count - 1);
    }
  };
  return (
    <div>
      <Title title="Voting App Demo" />
      <Text count={count} />
      <Button label="Up" fn={compute} />
      <Button label="Down" fn={compute} />
    </div>
  );
};
export default VotingApp;
/*
const VotingApp = ({ title }) => {
  console.log("Voting App Component call");
  const [count, setCount] = useState(0);
  //let count = 0;
  const plus = () => {
    // count++;
    setCount(count + 1);
    console.log("Count is ", count);
  };
  const minus = () => {
    //count--;
    setCount(count - 1);
    //setCount(count - 1);
    console.log("Count is ", count);
  };
  return (
    <div>
      <h1>{title}</h1>
      <p>Vote Count is {count}</p>
      <button onClick={plus}>Up</button> &nbsp;
      <button onClick={minus}>Down</button>
    </div>
  );
};
export default VotingApp;
*/

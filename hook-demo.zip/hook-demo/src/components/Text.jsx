const Text = ({ count }) => {
  return <p>Count is {count}</p>;
};
export default Text;

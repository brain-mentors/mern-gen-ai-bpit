export const Button = ({ label, fn }) => {
  return (
    <button
      onClick={() => {
        const opr = label == "Up" ? "+" : "-";
        fn(opr);
      }}
    >
      {label}
    </button>
  );
};

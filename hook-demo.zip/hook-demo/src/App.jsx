import VotingApp from "./pages/VotingApp";

const App = () => {
  console.log("App component call");
  return <VotingApp />;
};
export default App;

import { createRoot } from "react-dom/client";
import App from "./App";
const dom = document.querySelector("#root");
createRoot(dom).render(<App />);

// const Second = (props) => {
const Second = ({ x, y }) => {
  return (
    <h3>
      {/* I am the Second Component {props.x} {props.y} */}X is {x} and Y is {y}
    </h3>
  );
};
export default Second;

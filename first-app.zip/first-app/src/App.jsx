//import React from "react";
import "./App.css";
import Second from "./Second";
const App = () => {
  const myName = "Amit";
  const discount = 20;
  const songs = [
    { id: 1001, name: "Bang bang" },
    { id: 1002, name: "Boom Boom" },
  ];
  return (
    <div>
      <Second x="Hello" y="Hi" />
      <ul>
        {songs.map((song, index) => (
          <li key={song.id}>{song.name}</li>
        ))}
      </ul>
      {discount > 20 ? <p>Heavy Discount</p> : <p>low discount</p>}

      <h1 className="mystyle">Hello React JS</h1>
      <h2>Hi React</h2>
      <p style={{ backgroundColor: "red", color: "yellow" }}>
        Name is {myName}
      </p>
    </div>
  );
  // return React.createElement(
  //   "div",
  //   null,
  //   React.createElement("h1", null, "Hello React JS"),
  //   React.createElement("h1", null, "Hi React JS"),
  // ); // VDOM
};
export default App;

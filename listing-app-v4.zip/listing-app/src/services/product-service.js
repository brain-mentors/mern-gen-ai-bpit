import Product from "../models/product-model.js";

// Service contains Product Operations
 export const productOperations = {
    products:[],
    getProductSize(){
        return this.products.length;
    },
    getAllProducts(){
        return this.products;
    },
    mark(id){
        const productObject = this.products.find(product=>product.id == id);
        if(productObject){
            productObject.toggle();
        }
        console.log('Products ', this.products);
    },
    markCount(){
        return this.products.filter(product=>product.isMarked).length;
    },
    unMarkCount(){
        return this.getProductSize() - this.markCount();
    },
    // add:function(product){

    // }
    add(product){
       // this.products
        console.log(" I am in Service ", product);
        const productObject = new Product();
        for(let key in product){
            productObject[key] = product[key];
        }
        this.products.push(productObject);
        console.log('Product Array ', this.products);
        return productObject;
    },
    remove(){
        this.products = this.products.filter(product=>!product.isMarked)
    },
    search(){

    },
    update(){

    },
    sort(){

    }
}
//export default productOperations;
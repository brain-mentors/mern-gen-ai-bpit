class Product{
    constructor(id=0, name='', desc='', price=0.0, url=''){
        this.id = id;
        this.name = name;
        this.desc = desc;
        this.price = price;
        this.url = url;
    }
    
}
export default Product;
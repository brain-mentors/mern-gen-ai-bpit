//alert("I am in Controller");
import {productOperations} from '../services/product-service.js';
window.addEventListener('DOMContentLoaded', bindEvents);

function bindEvents(){
    
document.querySelector("#add").addEventListener("click", add);

}
function readFields(){
    const product = {}; // Object Literal
    const fields =['id', 'name', 'desc', 'price', 'url'];
    for(let field of fields){
        product[field] = document.querySelector(`#${field}`).value;
    }
    
    return product;
    // const id = document.querySelector('#id').value;
    // product.id = id;
    // const name = document.querySelector('#name').value;
    // product.name = name;
}
function add(){
    console.log(" Add Call");
   // read fields from view (UI)
   const product = readFields();
   const productObject = productOperations.add(product);
   print(productObject);
   //console.log(product);
}

function print(product){
    const tbody = document.querySelector('#products');
    const tr = tbody.insertRow();
    for(let key in product){
        const value = product[key];
        const td = tr.insertCell();
        td.innerText = value;
    }
    const td = tr.insertCell();
    td.appendChild(createIcon(product.id));
    td.appendChild(createIcon(product.id, 'fa-pen-to-square'))
}

function createIcon(productId, className ='fa-trash'){
    // <i class="fa-solid fa-trash"></i>
    const icon = document.createElement('i'); //<i></i>
    icon.setAttribute('product-id', productId);
    icon.className =`fa-solid ${className} hand`;
    return icon;
}

function toggleMark(id){

}

function edit(id){

}
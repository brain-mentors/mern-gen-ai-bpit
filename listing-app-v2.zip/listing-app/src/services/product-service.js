import Product from "../models/product-model.js";

// Service contains Product Operations
 export const productOperations = {
    products:[],
    // add:function(product){

    // }
    add(product){
       // this.products
        console.log(" I am in Service ", product);
        const productObject = new Product();
        for(let key in product){
            productObject[key] = product[key];
        }
        this.products.push(productObject);
        console.log('Product Array ', this.products);
        return productObject;
    },
    remove(){

    },
    search(){

    },
    update(){

    },
    sort(){

    }
}
//export default productOperations;
import QuoteApp from "./components/QuoteApp";

const App = () => {
  return <QuoteApp />;
};
export default App;

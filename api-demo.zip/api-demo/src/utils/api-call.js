import axios from 'axios';
function getQuote(){
    const URL = import.meta.env.VITE_URL;
    console.log('URL is ', URL);
    const API_KEY = import.meta.env.VITE_API_KEY; 
    const HEADER_NAME=import.meta.env.VITE_HEADER_NAME;
    const headerObject = {};
    headerObject[HEADER_NAME] = API_KEY;
    console.log(headerObject);
    return axios.get(URL, {
        headers:headerObject
    })
    
}
export default getQuote;
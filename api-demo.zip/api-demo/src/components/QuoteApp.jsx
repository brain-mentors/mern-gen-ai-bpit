import { useState } from "react";
import getQuote from "../utils/api-call";

const QuoteApp = () => {
  const [quote, setQuote] = useState("");
  const showQuote = async () => {
    try {
      const response = await getQuote();
      setQuote(response.data[0].quote);
      //console.log("Response is ", response.data[0].quote);
    } catch (e) {
      console.log("Error is ", e);
    }
  };
  return (
    <div>
      <h1>{quote}</h1>
      <button onClick={showQuote}>Get Quote</button>
    </div>
  );
};
export default QuoteApp;
